package com.mystery.CouchbaseDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouchbaseDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
