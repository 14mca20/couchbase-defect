package com.mystery.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mystery.models.Users;
import com.mystery.repository.UserRepository;

@Component
public class UserService {
	Logger logger = LoggerFactory.getLogger(UserService.class);

	/*
	 * @Autowired UserRepository userRepository;
	 */

	public UserService() {
		logger.info("Service class INFO");
		logger.debug("Service class DEBUG");
	}

	public void dummyMethod() {
		System.out.println("Dummy method called");
	}

	public void dummyMethod(Users users) {
		System.out.println("dummy method executed");
		// userRepository.save(users);
	}
}
