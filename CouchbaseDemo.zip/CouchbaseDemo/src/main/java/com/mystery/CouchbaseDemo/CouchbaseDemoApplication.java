package com.mystery.CouchbaseDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.couchbase.repository.config.EnableCouchbaseRepositories;
import org.springframework.data.couchbase.repository.config.EnableReactiveCouchbaseRepositories;

@SpringBootApplication
@ComponentScan(basePackages = { "com.mystery.controllers", "com.mystery.service","com.mystery.aspect","com.mystery.handler"})
@EnableAspectJAutoProxy()
@EnableCouchbaseRepositories(basePackages = "com.mystery.repository")
public class CouchbaseDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CouchbaseDemoApplication.class, args);
	}

}
