package com.mystery.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggerAspectService {
	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(LoggerAspectService.class);

	@Before("within(com.mystery.service.*)")
	public void beforeService(JoinPoint joinPoint) {
		LOGGER.info(log("entering", joinPoint));
	}

	@After("within(com.mystery.service.*)")
	public void afterService(JoinPoint joinPoint) {
		LOGGER.info(log("entering", joinPoint));
	}

	private String log(String message, JoinPoint joinPoint) {
		return "Autolog " + message + " " + joinPoint.getSignature() + " " + joinPoint.getKind();
	}
}
