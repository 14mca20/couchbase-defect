package com.mystery.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggerAspect {
	// private static final String POINTCUT = "execution(* com.mystery.controllers
	// ..*(..)) || execution(* com.mystery.service ..*(..))";
	// private static final String POINTCUT_SERVICE = "execution(*
	// com.mystery.controllers.*.*(..))";
	// com.mystery.service.*.*(..))";
	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(LoggerAspect.class);

	/*
	 * @Pointcut("within(com.mystery.controllers.*)") public void myPoint() {
	 * System.out.println("My Point called"); }
	 */

	@Before("within(com.mystery.controllers.*)")
	public void beforeAdvice(JoinPoint joinPoint) {
		LOGGER.info(log("entering", joinPoint));
	}

	@After("within(com.mystery.controllers.*)")
	public void afterAdvice(JoinPoint joinPoint) {
		LOGGER.info(log("Exiting", joinPoint));
	}

	private String log(String message, JoinPoint joinPoint) {
		return "Autolog " + message + " " + joinPoint.getSignature() + " " + joinPoint.getKind();
	}
}
