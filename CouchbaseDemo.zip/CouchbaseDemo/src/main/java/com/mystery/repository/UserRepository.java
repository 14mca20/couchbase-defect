package com.mystery.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.couchbase.repository.config.EnableCouchbaseRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.mystery.models.Users;


@Repository
public interface UserRepository extends CrudRepository<Users, String> {

	// Optional<Users> findById(String id);

	List<Users> findByFullName(String fullName);
}
