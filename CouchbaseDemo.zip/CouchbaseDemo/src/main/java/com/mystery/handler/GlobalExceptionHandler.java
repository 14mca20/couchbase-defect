package com.mystery.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.mystery.exceptions.BadRequestCustomException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = { BadRequestCustomException.class })
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Errors handleBadRequestExceptions(BadRequestCustomException e) {
		Errors errors = new Errors(e.getHttpStatus(), e.getError_title());
		System.out.println("Controller advice cought" + e);
		return errors;
	}

	@ExceptionHandler(value = { Exception.class })
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public Errors unKnownException(Exception ex) {
		return new Errors(HttpStatus.NOT_FOUND, "Not found");
	}
}
