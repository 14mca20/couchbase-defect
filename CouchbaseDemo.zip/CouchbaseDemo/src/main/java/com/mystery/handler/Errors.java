package com.mystery.handler;

import org.springframework.http.HttpStatus;

public class Errors {
	private HttpStatus statusCode;

	private String message;

	public Errors(HttpStatus statusCode, String message) {
		this.statusCode = statusCode;

		this.message = message;

	}

	public HttpStatus getStatusCode() {
		return statusCode;
	}

	public String getMessage() {
		return message;
	}

}
