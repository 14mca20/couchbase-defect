package com.mystery.models;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ListModel {
	List<Map<String, String>> myList;

	@Override
	public String toString() {
		return "ListModel [myList=" + myList + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(myList);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ListModel other = (ListModel) obj;
		return Objects.equals(myList, other.myList);
	}

	public List<Map<String, String>> getMyList() {
		return myList;
	}

	public void setMyList(List<Map<String, String>> myList) {
		this.myList = myList;
	}
}
