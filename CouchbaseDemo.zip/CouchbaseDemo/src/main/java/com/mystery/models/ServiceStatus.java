package com.mystery.models;

import org.springframework.http.HttpStatus;

public class ServiceStatus {
	public String status = null;
	public HttpStatus HTTP_STATUS = null;

	public ServiceStatus() {
		this.status = "Service B is running";
		this.HTTP_STATUS = HttpStatus.OK;
	}

	public String getStatus() {
		return status;
	}

	public HttpStatus getHttpStatus() {
		return HTTP_STATUS;
	}

}
