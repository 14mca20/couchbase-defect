package com.mystery.exceptions;

import org.springframework.http.HttpStatus;

public class InvalidCompanyException {

	private final HttpStatus httpStatus;
	private final String errorMessage;

	public InvalidCompanyException(HttpStatus httpStatus, String errorMessage) {
		super();
		this.httpStatus = httpStatus;
		this.errorMessage = errorMessage;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
