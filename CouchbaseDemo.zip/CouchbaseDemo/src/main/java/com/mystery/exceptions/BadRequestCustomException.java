package com.mystery.exceptions;

import org.springframework.http.HttpStatus;

public class BadRequestCustomException extends Exception{
	HttpStatus httpStatus;
	String error_title,error_code;

	public BadRequestCustomException(HttpStatus http_status, String error_title, String error_code) {
		super();
		this.httpStatus = http_status;
		this.error_title = error_title;
		this.error_code = error_code;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public String getError_title() {
		return error_title;
	}

	public String getError_code() {
		return error_code;
	}
	
}
