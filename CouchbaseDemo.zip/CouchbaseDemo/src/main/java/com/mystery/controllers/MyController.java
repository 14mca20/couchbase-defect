package com.mystery.controllers;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.mystery.exceptions.BadRequestCustomException;
import com.mystery.models.ListModel;
import com.mystery.models.ServiceStatus;
import com.mystery.models.Users;
import com.mystery.repository.UserRepository;
import com.mystery.service.UserService;

import reactor.core.publisher.Mono;

@RestController
@ConfigurationProperties
@Component
public class MyController {
	org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(MyController.class);

	@Autowired
	UserService userService;

	@Value("${services.serviceB.url}")
	String serviceBUrl;

	@GetMapping("/appStatus")
	public ResponseEntity<HttpStatus> getAppStatus() {
		logger.info("Info log with value {} ", 3.5);
		UserService service = new UserService();
		service.dummyMethod();
		return new ResponseEntity<HttpStatus>(HttpStatus.OK);
	}

	@PostMapping("/addList")
	public ResponseEntity<List<Map<String, String>>> passList(@RequestBody ListModel listModel) {
		System.out.println("List mapped " + listModel);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	public String dummyTwo() {
		System.out.println("New dummy");
		return null;
	}

	@PostMapping("/addUser")
	public ResponseEntity<Object> addNewUser(@RequestBody Users user) {
		System.out.println("Saving a new user to couchbase");
		System.out.println("Input supplied " + user.toString());
		// userService.dummyMethod(user);
		/*
		 * if (user.getCompany().equals("other")) { InvalidCompanyException
		 * companyException = new InvalidCompanyException(HttpStatus.BAD_REQUEST,
		 * "Company name wrong!");
		 * 
		 * return new ResponseEntity<>(companyException,
		 * companyException.getHttpStatus()); }
		 */

		return new ResponseEntity<>(user, HttpStatus.CREATED);
	}

	@GetMapping("/callServiceB")
	public Mono<String> callServiceB() {
		System.out.println("Calling service with URL :" + serviceBUrl);

		WebClient client = WebClient.create(serviceBUrl);
		return client.get().uri("/status").retrieve().bodyToMono(String.class);
		// l̥return serviceResponse.toString();

	}

	@GetMapping("/getServiceBModel")
	public Mono<ServiceStatus> getServiceBModel() {
		WebClient client = WebClient.create(serviceBUrl);
		// Mono<ClientResponse> clientResponse =
		// client.get().uri("/getCustomModel").exchange();
		return client.get().uri("/getCustomModel").retrieve().bodyToMono(ServiceStatus.class);
		// return "Model obtained";
	}

	@PutMapping("/putBadData")
	public ResponseEntity<HttpStatus> putBadDataCheck(@RequestBody Users user) throws BadRequestCustomException {
		if (user.getCompany().equals("other")) {
			throw new BadRequestCustomException(HttpStatus.BAD_REQUEST, "INVALID_COMPANY_NAME", "ERR_400_01");

		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PutMapping("/putBadData2")
	public ResponseEntity<HttpStatus> putBadDataCheck2(@RequestBody Users user) throws BadRequestCustomException {
		if (user.getCompany().equals("TCS")) {
			throw new BadRequestCustomException(HttpStatus.BAD_REQUEST, "INVALID_COMPANY_NAME_TCS", "ERR_400_01");

		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping("/multipleParam")
	public String demoMultipleParam(@RequestParam(value = "name", defaultValue = "Harsh") String myParam)
			throws BadRequestCustomException {
		List<String> list = Arrays.asList(myParam.split(","));
		if (list.size() > 1)
			throw new BadRequestCustomException(HttpStatus.BAD_REQUEST, "Multiple values passed in query param",
					"ERR_400_02");
		return myParam + " was passed";
	}
}
